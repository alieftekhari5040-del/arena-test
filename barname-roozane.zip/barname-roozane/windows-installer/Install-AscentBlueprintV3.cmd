@echo off
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-AscentBlueprintV3.ps1"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
  echo.
  echo Installation could not finish. Review the error above.
  pause
  exit /b %RC%
)
echo.
echo Installation completed. The app will open shortly.
timeout /t 2 /nobreak >nul
exit /b 0
