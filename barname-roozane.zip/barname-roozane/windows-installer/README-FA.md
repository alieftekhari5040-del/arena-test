# نصب‌کنندهٔ ویندوز — Daily Planner V3

## روش نصب

1. کل پوشهٔ `ascent-blueprint-v3` را دانلود یا Extract کنید؛ هیچ‌کدام از فایل‌ها را جدا نکنید.
2. وارد پوشهٔ `windows-installer` شوید.
3. روی `Install-DailyPlannerV3.cmd` دوبارکلیک کنید.
4. پس از چند ثانیه، برنامه در مرورگر باز می‌شود و یک میانبر در Desktop و Start Menu ساخته می‌شود.
5. در Chrome یا Edge، در آدرس `http://localhost:8765` گزینهٔ **Install app** را بزنید تا مانند اپ مستقل نصب شود.

## این نصب‌کننده چه می‌کند؟

- فایل‌ها را به `%LOCALAPPDATA%\DailyPlannerV3` کپی می‌کند.
- سرور محلی ایمن برای PWA روی `localhost:8765` راه می‌اندازد.
- میانبر Desktop و Start Menu می‌سازد.
- به Administrator نیاز ندارد.
- هیچ داده‌ای به اینترنت ارسال نمی‌کند.

## حذف

در مسیر زیر، فایل `Uninstall-DailyPlannerV3.ps1` را اجرا کنید:

```text
%LOCALAPPDATA%\DailyPlannerV3
```

> داده‌های برنامه در Local Storage مرورگر نگهداری می‌شوند. پیش از حذف مرورگر یا پاک‌سازی داده‌ها، از بخش تنظیمات برنامه «خروجی JSON» بگیرید.
