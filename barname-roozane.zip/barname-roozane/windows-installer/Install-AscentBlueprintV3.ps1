﻿# Daily Planner V3 - Windows installer
# Run via Install-DailyPlannerV3.cmd or PowerShell.
[CmdletBinding()]
param([switch]$NoLaunch)
$ErrorActionPreference = 'Stop'
if ($env:OS -ne 'Windows_NT') { throw 'This installer is designed for Windows only.' }
$sourceRoot = Split-Path -Parent $PSScriptRoot
$targetRoot = Join-Path $env:LOCALAPPDATA 'DailyPlannerV3'
$desktop = [Environment]::GetFolderPath('Desktop')
$startMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'

function Copy-AppFile([string]$name) {
  $from = Join-Path $sourceRoot $name
  if (-not (Test-Path $from)) { throw "Required file not found: $name" }
  Copy-Item -Path $from -Destination (Join-Path $targetRoot $name) -Force
}

Write-Host 'Installing Daily Planner V3 ...' -ForegroundColor Cyan
New-Item -ItemType Directory -Path $targetRoot -Force | Out-Null
Copy-AppFile 'index.html'; Copy-AppFile 'manifest.webmanifest'; Copy-AppFile 'service-worker.js'
foreach ($folder in @('assets','styles','scripts')) {
  $from = Join-Path $sourceRoot $folder
  if (-not (Test-Path $from)) { throw "Required folder not found: $folder" }
  Copy-Item -Path $from -Destination $targetRoot -Recurse -Force
}

$runner = @'
# Local static server. Uses TcpListener, so it does not require an HTTP URL reservation or Administrator rights.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSCommandPath
$port = 8765
$url = "http://127.0.0.1:$port/index.html"
$log = Join-Path $root 'server.log'
function Write-Log([string]$Message) { "$(Get-Date -Format o) $Message" | Add-Content -Path $log -Encoding UTF8 }
$mime = @{'.html'='text/html; charset=utf-8';'.js'='text/javascript; charset=utf-8';'.css'='text/css; charset=utf-8';'.json'='application/json; charset=utf-8';'.webmanifest'='application/manifest+json';'.png'='image/png';'.ico'='image/x-icon';'.woff2'='font/woff2'}
try {
  $listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, $port)
  $listener.Start()
  Write-Log "Server started at $url"
} catch {
  Write-Log "Port $port already in use or server could not start: $($_.Exception.Message)"
  Start-Process $url
  exit
}
Start-Process $url
$base = [IO.Path]::GetFullPath($root) + [IO.Path]::DirectorySeparatorChar
while ($true) {
  $client = $null
  try {
    $client = $listener.AcceptTcpClient()
    $stream = $client.GetStream()
    $reader = New-Object IO.StreamReader($stream, [Text.Encoding]::ASCII, $false, 8192, $true)
    $firstLine = $reader.ReadLine()
    while ($true) { $line = $reader.ReadLine(); if ($null -eq $line -or $line -eq '') { break } }
    $status = '200 OK'; $body = [byte[]]@(); $contentType = 'text/plain; charset=utf-8'
    if ([string]::IsNullOrWhiteSpace($firstLine) -or -not $firstLine.StartsWith('GET ')) {
      $status = '405 Method Not Allowed'; $body = [Text.Encoding]::UTF8.GetBytes('Method not allowed')
    } else {
      $requestPath = ($firstLine -split ' ')[1].Split('?')[0]
      $requestPath = [Uri]::UnescapeDataString($requestPath).TrimStart('/')
      if ([string]::IsNullOrWhiteSpace($requestPath)) { $requestPath = 'index.html' }
      $requestPath = $requestPath.Replace('/', [IO.Path]::DirectorySeparatorChar)
      $file = [IO.Path]::GetFullPath((Join-Path $root $requestPath))
      if (-not $file.StartsWith($base, [StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path $file -PathType Leaf)) {
        $status = '404 Not Found'; $body = [Text.Encoding]::UTF8.GetBytes('404 - Not found')
      } else {
        $body = [IO.File]::ReadAllBytes($file); $ext = [IO.Path]::GetExtension($file).ToLowerInvariant()
        if ($mime.ContainsKey($ext)) { $contentType = $mime[$ext] } else { $contentType = 'application/octet-stream' }
      }
    }
    $header = "HTTP/1.1 $status`r`nContent-Type: $contentType`r`nContent-Length: $($body.Length)`r`nCache-Control: no-cache`r`nConnection: close`r`n`r`n"
    $head = [Text.Encoding]::ASCII.GetBytes($header)
    $stream.Write($head, 0, $head.Length); if ($body.Length -gt 0) { $stream.Write($body, 0, $body.Length) }; $stream.Flush()
  } catch { Write-Log "Request error: $($_.Exception.Message)" }
  finally { if ($client) { $client.Close() } }
}
'@
Set-Content -Path (Join-Path $targetRoot 'Run-DailyPlannerV3.ps1') -Value $runner -Encoding UTF8

$uninstaller = @'
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSCommandPath
$desktop = [Environment]::GetFolderPath('Desktop')
$startMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
Remove-Item (Join-Path $desktop 'Daily Planner V3.lnk') -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path $startMenu 'Daily Planner V3.lnk') -Force -ErrorAction SilentlyContinue
Remove-Item $root -Recurse -Force
'@
Set-Content -Path (Join-Path $targetRoot 'Uninstall-DailyPlannerV3.ps1') -Value $uninstaller -Encoding UTF8

$wsh = New-Object -ComObject WScript.Shell
$target = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
$launchArgs = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$(Join-Path $targetRoot 'Run-DailyPlannerV3.ps1')`""
foreach ($shortcutPath in @((Join-Path $desktop 'Daily Planner V3.lnk'), (Join-Path $startMenu 'Daily Planner V3.lnk'))) {
  $shortcut = $wsh.CreateShortcut($shortcutPath)
  $shortcut.TargetPath = $target; $shortcut.Arguments = $launchArgs; $shortcut.WorkingDirectory = $targetRoot
  $shortcut.IconLocation = (Join-Path $targetRoot 'assets\icons\AscentBlueprint.ico')
  $shortcut.Description = 'Daily Planner V3 - Planner and Habit Tracker'
  $shortcut.Save()
}
Set-Content -Path (Join-Path $targetRoot 'INSTALLATION.txt') -Value "Installed: $(Get-Date -Format o)`nURL: http://localhost:8765/index.html" -Encoding UTF8
Write-Host "Installation successful: $targetRoot" -ForegroundColor Green
Write-Host 'Desktop and Start Menu shortcuts were created.' -ForegroundColor Green
if (-not $NoLaunch) {
  try { Start-Process -FilePath $target -ArgumentList $launchArgs }
  catch { Write-Host 'Installed successfully, but automatic launch failed. Use the Desktop shortcut.' -ForegroundColor Yellow }
}
exit 0
